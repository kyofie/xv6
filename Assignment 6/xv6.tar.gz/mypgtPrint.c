#include "types.h"
#include "user.h"
#include "date.h"

int arrGlobal[100000];

int main(int argc, char *argv[])
{
  /*
  int arrLocal[1000000];
  arrLocal[0] = 0;
  printf(1,"%d\n",arrLocal[0]);*/
  pgtPrint();
  exit();
}

