#include "types.h"
#include "stat.h"
#include "user.h"

#define N 300
int glob[N];

int main() {
    glob[0] = 2; 
    printf(1, "global addr from user space: %x\n", glob);

    for (int i = 1; i < N; i++) {
        glob[i] = glob[i - 1];
        if (i % 1000 == 0) {
            pgtPrint();
        }
    }

    int pid = fork();
    if (pid == 0) {
        // child process
        printf(1, "Child process:\n");
        printf(1, "global addr from user space: %x\n", glob);
        for (int i = 0; i < N; i++) {
            glob[i] += 1;  //writes
            if (i % 1000 == 0) {
                pgtPrint();
            }
        }
        printf(1, "Value in child process: %d\n", glob[N - 1]);
        exit();
    } 
    else if (pid > 0) {
        // parent process
        wait();
        printf(1, "Parent process:\n");
        printf(1, "global addr from user space: %x\n", glob);
        for (int i = 0; i < N; i++) {
            glob[i] += 2; //writes
            if (i % 1000 == 0) {
                pgtPrint();
            }
        }
        printf(1, "Value in parent process: %d\n", glob[N - 1]);
    } 
    else {
        printf(1, "fork failed\n");
    }

    exit();
}

